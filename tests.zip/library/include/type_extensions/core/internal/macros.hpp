#pragma once
// The namespace type_extensions lives in. Define before including any type_extensions
// header to change it.
#ifndef TYPE_EXTNSNS_NAMESPACE
    #define TYPE_EXTNSNS_NAMESPACE type_extensions
#endif
// The namespace, inside TYPE_EXTNSNS_NAMESPACE, for implementation details.
#ifndef TYPE_EXTNSNS_INTERNAL_NAMESPACE
    #define TYPE_EXTNSNS_INTERNAL_NAMESPACE internal
#endif

#define TYPE_EXTNSNS_NS ::TYPE_EXTNSNS_NAMESPACE
#define TYPE_EXTNSNS_INTERNAL_NS ::TYPE_EXTNSNS_NAMESPACE::TYPE_EXTNSNS_INTERNAL_NAMESPACE

// Begins the type_extensions namespace. Users specialise type_extensions'
// traits between these, without needing to know the namespace's name.
#define TYPE_EXTNSNS_NS_BEGIN       \
    namespace TYPE_EXTNSNS_NAMESPACE \
    {
// Ends the type_extensions namespace.
#define TYPE_EXTNSNS_NS_END }
// Begins the internal namespace (inside the type_extensions namespace).
#define TYPE_EXTNSNS_INTERNAL_NS_BEGIN        \
    namespace TYPE_EXTNSNS_INTERNAL_NAMESPACE \
    {
// Ends the internal namespace.
#define TYPE_EXTNSNS_INTERNAL_NS_END }
