#pragma once
/*!
 * @file
 * @brief std::unordered_multimap: built with insert, from std::pair<Key, T>.
 *
 * Specialises default_appender. Its sequence traits are detected (it's
 * iterable, with a value_type).
 */
#include "type_extensions/core/appenders.hpp"
#include "type_extensions/core/appenders/multi_insert.hpp"
#include "type_extensions/core/internal/macros.hpp"

// std::unordered_multimap.
#include <unordered_map>

TYPE_EXTNSNS_NS_BEGIN

template <
    typename Key,
    typename T,
    typename Hash,
    typename KeyEqual,
    typename Allocator>
struct default_appender<
    std::unordered_multimap<Key, T, Hash, KeyEqual, Allocator>>
    : multi_insert_appender<
          std::unordered_multimap<Key, T, Hash, KeyEqual, Allocator>>
{
    using multi_insert_appender<
        std::unordered_multimap<Key, T, Hash, KeyEqual, Allocator>>::
        multi_insert_appender;
};

TYPE_EXTNSNS_NS_END
