#pragma once
/*!
 * @file
 * @brief std::unordered_multiset: built with insert.
 *
 * Specialises default_appender. Its sequence traits are detected (it's
 * iterable, with a value_type).
 */
#include "type_extensions/core/appenders.hpp"
#include "type_extensions/core/appenders/multi_insert.hpp"
#include "type_extensions/core/internal/macros.hpp"

 // std::unordered_multiset.
#include <unordered_set>

TYPE_EXTNSNS_NS_BEGIN

template <typename Key, typename Hash, typename KeyEqual, typename Allocator>
struct default_appender<std::unordered_multiset<Key, Hash, KeyEqual, Allocator>>
    : multi_insert_appender<std::unordered_multiset<Key, Hash, KeyEqual, Allocator>>
{
    using multi_insert_appender<std::unordered_multiset<Key, Hash, KeyEqual, Allocator>>::multi_insert_appender;
};

TYPE_EXTNSNS_NS_END
