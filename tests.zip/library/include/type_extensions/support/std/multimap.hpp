#pragma once
/*!
 * @file
 * @brief std::multimap: built with insert, from std::pair<Key, T>.
 *
 * Specialises default_appender. Its sequence traits are detected (it's
 * iterable, with a value_type).
 */
#include "type_extensions/core/appenders.hpp"
#include "type_extensions/core/appenders/multi_insert.hpp"
#include "type_extensions/core/internal/macros.hpp"

 // std::multimap.
#include <map>

TYPE_EXTNSNS_NS_BEGIN

template <typename Key, typename T, typename Compare, typename Allocator>
struct default_appender<std::multimap<Key, T, Compare, Allocator>>
    : multi_insert_appender<std::multimap<Key, T, Compare, Allocator>>
{
    using multi_insert_appender<std::multimap<Key, T, Compare, Allocator>>::multi_insert_appender;
};

TYPE_EXTNSNS_NS_END
