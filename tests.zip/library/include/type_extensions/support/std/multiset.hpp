#pragma once
/*!
 * @file
 * @brief std::multiset: built with insert.
 *
 * Specialises default_appender. Its sequence traits are detected (it's
 * iterable, with a value_type).
 */
#include "type_extensions/core/appenders.hpp"
#include "type_extensions/core/appenders/multi_insert.hpp"
#include "type_extensions/core/internal/macros.hpp"

 // std::multiset.
#include <set>

TYPE_EXTNSNS_NS_BEGIN

template <typename Key, typename Compare, typename Allocator>
struct default_appender<std::multiset<Key, Compare, Allocator>>
    : multi_insert_appender<std::multiset<Key, Compare, Allocator>>
{
    using multi_insert_appender<std::multiset<Key, Compare, Allocator>>::multi_insert_appender;
};

TYPE_EXTNSNS_NS_END
