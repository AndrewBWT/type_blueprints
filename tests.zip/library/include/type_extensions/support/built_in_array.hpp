#pragma once
/*!
 * @file
 * @brief Built-in arrays: filled by index.
 *
 * Specialises default_appender. Their sequence traits, including the fixed
 * count, are detected.
 */
#include "type_extensions/core/appenders.hpp"
#include "type_extensions/core/appenders/fixed_size.hpp"
#include "type_extensions/core/internal/macros.hpp"

 // std::size_t.
#include <cstddef>

TYPE_EXTNSNS_NS_BEGIN

template <typename T, std::size_t N>
struct default_appender<T[N]> : fixed_size_appender<T[N]>
{
    using fixed_size_appender<T[N]>::fixed_size_appender;
};

TYPE_EXTNSNS_NS_END
