# Guard against rebuilding by accident.
if(NOT DEFINED TYPE_EXTENSIONS_TESTS_INCLUDED)
  set(TYPE_EXTENSIONS_TESTS_INCLUDED TRUE)
  # Set library name so that, if we change it, we only have to change this line
  # Set the name of the example executable once
  set(TYPE_EXTENSIONS_TESTS_EXECUTABLE_NAME type_extensions_tests)

  # The set of all test files. The idea behind these is they mirror the files in the library.
  # However we may change this as we move forward.

  FetchContent_Declare(
    Catch2
    GIT_REPOSITORY https://github.com/catchorg/Catch2.git
    GIT_TAG        v3.7.1  # pin to a specific release
  )
  FetchContent_MakeAvailable(Catch2)
  # These are the libs required for the testing suite.
  set(TYPE_EXTENSIONS_TESTS_REQUIRED_LIBS
    Catch2::Catch2
    type_extensions::type_extensions
  )

  #There are some additional entries at the end which are not mirrored by files in the library.
  set(TYPE_EXTENSIONS_TESTS_FILES
    include/type_extensions_tests/core/enum.hpp
    include/type_extensions_tests/core/extended_concepts.hpp
    include/type_extensions_tests/core/tuples.hpp
    include/type_extensions_tests/core.hpp
    include/type_extensions_tests/core/sequence_traits.hpp
    src/main.cpp
  )
  
  # Sets how the IDE organises the files.
  source_group(TREE ${CMAKE_CURRENT_SOURCE_DIR}/.. FILES
    ${TYPE_EXTENSIONS_TESTS_FILES}
  )

  # Add the set of files to executable.
  add_executable(${TYPE_EXTENSIONS_TESTS_EXECUTABLE_NAME} ${TYPE_EXTENSIONS_TESTS_FILES})
  
  set_common_compile_options(${TYPE_EXTENSIONS_TESTS_EXECUTABLE_NAME})
  
  # Add the include directory to the target.
  target_include_directories(${TYPE_EXTENSIONS_TESTS_EXECUTABLE_NAME} PRIVATE include)
  # Link the REQUIRED_LIBS to the LIBRARY.
  target_link_libraries(${TYPE_EXTENSIONS_TESTS_EXECUTABLE_NAME} PUBLIC ${TYPE_EXTENSIONS_TESTS_REQUIRED_LIBS})

  # The library is header-only (an INTERFACE target), so it has no compile
  # settings of its own, and IntelliSense falls back to defaults for its
  # headers. Listing them in this compiled target gives them its settings.
  # Uses the real target name: get_target_property doesn't accept aliases.
  get_target_property(TYPE_EXTENSIONS_HEADERS type_extensions HEADER_SET_public_headers)
  target_sources(${TYPE_EXTENSIONS_TESTS_EXECUTABLE_NAME} PRIVATE ${TYPE_EXTENSIONS_HEADERS})
  # Show them in the IDE in the library's folder structure.
  source_group(TREE ${CMAKE_CURRENT_SOURCE_DIR}/.. FILES ${TYPE_EXTENSIONS_HEADERS})

  # Header checks: one generated translation unit per header, containing only
  # that header's #include. Checks every header compiles on its own (no
  # missing includes hidden by main.cpp).
  foreach(header IN LISTS TYPE_EXTENSIONS_HEADERS)
    string(MAKE_C_IDENTIFIER "${header}" header_id)
    set(check_file "${CMAKE_CURRENT_BINARY_DIR}/header_checks/${header_id}.cpp")
    file(CONFIGURE OUTPUT "${check_file}" CONTENT "#include \"${header}\"\n")
    list(APPEND TYPE_EXTENSIONS_HEADER_CHECKS "${check_file}")
  endforeach()
  add_library(type_extensions_header_checks OBJECT ${TYPE_EXTENSIONS_HEADER_CHECKS})
  target_link_libraries(type_extensions_header_checks PRIVATE type_extensions::type_extensions)
  set_common_compile_options(type_extensions_header_checks)
  # The generated files live in the build folder, outside the TREE root above,
  # so they get a flat group of their own.
  source_group("Header checks" FILES ${TYPE_EXTENSIONS_HEADER_CHECKS})
  
  # Adds the test as a command.
  add_test(NAME "Run type_extensions test suite executable"
           COMMAND ${TYPE_EXTENSIONS_TESTS_EXECUTABLE_NAME} "--config" ${TYPE_EXTENSIONS_TEST_RUN_ARGS})
endif()